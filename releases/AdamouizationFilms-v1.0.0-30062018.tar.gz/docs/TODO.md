AdamouizationFilms Website TODO
===============================

## TODO

### Features to add
* [ ] add "back to top button" -  especially for mobile
* [ ] add additional pages (terms & conditions, credits?) 

### Design
* [ ] add logo to navbar
* [ ] disable green button when sending form

### Code improvements
* no tasks at the moment

### Bug fixes
* no tasks at the moment

## Completed
* [X] complete about me section 
* [X] change portfolio item hover from search to youtube play button
* [X] make contact form functional
* [X] enable google analytics
* [X] mobile home screen icon
* [X] download necessary third-party libraries to improve loading speed
* [X] start embedded videos at specific time (add extra field to all posts with time)
* [X] add all portfolio entries
* [X] fix youtube iframes width when viewing on mobile (make fit if mobile)
* [X] use optimised thumbnails for ratio used OR change image ratio
* [X] fix form bug
* [X] remove links to Vine page